package com.okip.service.mentorship.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.okip.dto.mentorship.CreateFeedbackDTO;
import com.okip.dto.mentorship.CreateKnowledgeSessionDTO;
import com.okip.dto.mentorship.CreateMentorshipRequestDTO;
import com.okip.dto.mentorship.KnowledgeSessionDTO;
import com.okip.dto.mentorship.MentorRecommendationDTO;
import com.okip.dto.mentorship.MentorshipRequestDTO;
import com.okip.entity.master.Employee;
import com.okip.entity.master.Skill;
import com.okip.entity.transaction.KnowledgeGap;
import com.okip.entity.transaction.KnowledgeSession;
import com.okip.entity.transaction.KnowledgeSessionFeedback;
import com.okip.entity.transaction.MentorshipRequest;
import com.okip.enums.ProficiencyLevel;
import com.okip.enums.RoleType;
import com.okip.exception.ResourceAlreadyExistsException;
import com.okip.exception.ResourceNotFoundException;
import com.okip.repository.EmployeeRepository;
import com.okip.repository.EmployeeSkillRepository;
import com.okip.repository.KnowledgeGapRepository;
import com.okip.repository.KnowledgeSessionFeedbackRepository;
import com.okip.repository.KnowledgeSessionRepository;
import com.okip.repository.MentorshipRequestRepository;
import com.okip.repository.SkillRepository;
import com.okip.service.mentorship.MentorshipService; 

@Service
@Transactional
public class MentorshipServiceImpl implements MentorshipService {

    private final EmployeeRepository employeeRepository;
    private final EmployeeSkillRepository employeeSkillRepository;
    private final KnowledgeGapRepository knowledgeGapRepository;
    private final MentorshipRequestRepository requestRepository;
    private final KnowledgeSessionRepository sessionRepository;
    private final KnowledgeSessionFeedbackRepository feedbackRepository;
    private final SkillRepository skillRepository;

    public MentorshipServiceImpl(
            EmployeeRepository employeeRepository,
            EmployeeSkillRepository employeeSkillRepository,
            KnowledgeGapRepository knowledgeGapRepository,
            MentorshipRequestRepository requestRepository,
            KnowledgeSessionRepository sessionRepository,
            KnowledgeSessionFeedbackRepository feedbackRepository,
            SkillRepository skillRepository) {
        this.employeeRepository = employeeRepository;
        this.employeeSkillRepository = employeeSkillRepository;
        this.knowledgeGapRepository = knowledgeGapRepository;
        this.requestRepository = requestRepository;
        this.sessionRepository = sessionRepository;
        this.feedbackRepository = feedbackRepository;
        this.skillRepository = skillRepository;
    }

     @Override
@Transactional(readOnly = true)
public List<MentorRecommendationDTO> getRecommendations() {

    Employee mentee = getLoggedInEmployee();

    List<KnowledgeGap> openGaps = knowledgeGapRepository
            .findByEmployeeJobRole_Employee_EmployeeId(mentee.getEmployeeId())
            .stream()
            .filter(g -> g.getStatus() == com.okip.enums.GapStatus.OPEN)
            .sorted(Comparator.comparing(
                    (KnowledgeGap g) ->
                            Optional.ofNullable(g.getGapPercentage()).orElse(0.0)
            ).reversed())
            .collect(Collectors.toList());

    List<MentorRecommendationDTO> result = new ArrayList<>();
    Set<String> seen = new HashSet<>();

    for (KnowledgeGap gap : openGaps) {

        Skill skill = gap.getSkill();

        if (skill == null) {
            continue;
        }

        List<com.okip.entity.transaction.EmployeeSkill> experts =
                employeeSkillRepository.findAll()
                        .stream()
                        .filter(es -> es.getEmployee() != null)

                        // Do not recommend the logged-in employee
                        .filter(es ->
                                !es.getEmployee()
                                        .getEmployeeId()
                                        .equals(mentee.getEmployeeId()))

                        // Only employees with ROLE_MENTOR
                        .filter(es ->
                                es.getEmployee().getRole() != null
                                && es.getEmployee()
                                        .getRole()
                                        .getRoleName()
                                        == RoleType.ROLE_MENTOR)

                        // Same skill
                        .filter(es ->
                                es.getSkill() != null
                                && es.getSkill()
                                        .getSkillId()
                                        .equals(skill.getSkillId()))

                        // Mentor must have stronger proficiency
                        // OR more experience than the mentee's current level
                        .filter(es ->
                                proficiencyRank(es.getProficiencyLevel())
                                        > proficiencyRank(
                                                gap.getCurrentProficiency())

                                || Optional.ofNullable(
                                        es.getYearsOfExperience())
                                        .orElse(0.0)
                                        > Optional.ofNullable(
                                                gap.getCurrentExperience())
                                        .orElse(0.0)
                        )

                        // Strongest mentors first
                        .sorted(
                                Comparator.comparingInt(
                                        (com.okip.entity.transaction.EmployeeSkill es) ->
                                                proficiencyRank(
                                                        es.getProficiencyLevel())
                                ).reversed()
                        )

                        .collect(Collectors.toList());

        for (com.okip.entity.transaction.EmployeeSkill expert : experts) {

            String key =
                    expert.getEmployee().getEmployeeId()
                            + ":" + skill.getSkillId();

            if (!seen.add(key)) {
                continue;
            }

            MentorRecommendationDTO dto =
                    new MentorRecommendationDTO();

            Employee e = expert.getEmployee();

            dto.setEmployeeId(e.getEmployeeId());
            dto.setEmployeeCode(e.getEmployeeCode());
            dto.setName(fullName(e));

            dto.setDepartment(
                    e.getDepartment() == null
                            ? null
                            : e.getDepartment().getDepartmentName()
            );

            dto.setRole(
                    e.getRole() == null
                            ? null
                            : e.getRole().getRoleName().name()
            );

            dto.setSkillId(skill.getSkillId());
            dto.setSkillName(skill.getSkillName());

            dto.setProficiency(
                    expert.getProficiencyLevel().name()
            );

            dto.setYearsOfExperience(
                    Optional.ofNullable(
                            expert.getYearsOfExperience()
                    ).orElse(0.0)
            );

            dto.setGapPercentage(gap.getGapPercentage());

            result.add(dto);
        }
    }

    return result.stream()
            .limit(10)
            .collect(Collectors.toList());
}

    @Override
    @Transactional(readOnly = true)
    public List<MentorshipRequestDTO> getMyRequests() {
        Employee employee = getLoggedInEmployee();
        return requestRepository.findByMenteeOrMentorOrderByCreatedAtDesc(employee, employee)
                .stream().map(this::toRequestDto).collect(Collectors.toList());
    }

    @Override
    public MentorshipRequestDTO createRequest(CreateMentorshipRequestDTO request) {
        Employee mentee = getLoggedInEmployee();
        if (request.getMentorId() == null || request.getSkillId() == null) {
            throw new IllegalArgumentException("mentorId and skillId are required.");
        }
        Employee mentor = employeeRepository.findById(request.getMentorId())
        .orElseThrow(() -> new ResourceNotFoundException("Mentor not found."));

if (mentor.getEmployeeId().equals(mentee.getEmployeeId())) {
    throw new IllegalArgumentException(
            "You cannot request yourself as a mentor.");
}

if (mentor.getRole() == null
        || mentor.getRole().getRoleName() != RoleType.ROLE_MENTOR) {

    throw new IllegalArgumentException(
            "Selected employee is not registered as a mentor.");
}
        Skill skill = skillRepository.findById(request.getSkillId())
                .orElseThrow(() -> new ResourceNotFoundException("Skill not found."));

        boolean qualified = employeeSkillRepository.findByEmployeeAndSkill(mentor, skill)
                .map(es -> proficiencyRank(es.getProficiencyLevel()) > 0)
                .orElse(false);
        if (!qualified) {
            throw new IllegalArgumentException("Selected employee is not a qualified mentor for this skill.");
        }

        requestRepository.findByMenteeAndMentorAndSkillAndStatusIn(
                mentee, mentor, skill,
                List.of(MentorshipRequest.Status.PENDING, MentorshipRequest.Status.ACCEPTED))
                .ifPresent(existing -> {
                    throw new ResourceAlreadyExistsException("An active mentorship request already exists for this mentor and skill.");
                });

        MentorshipRequest entity = new MentorshipRequest();
        entity.setMentee(mentee);
        entity.setMentor(mentor);
        entity.setSkill(skill);
        entity.setMessage(request.getMessage());
        entity.setStatus(MentorshipRequest.Status.PENDING);
        return toRequestDto(requestRepository.save(entity));
    }

    @Override
    public MentorshipRequestDTO acceptRequest(Long requestId) {
        MentorshipRequest request = getRequest(requestId);
        Employee employee = getLoggedInEmployee();
        requireMentor(request, employee);
        if (request.getStatus() != MentorshipRequest.Status.PENDING) {
            throw new IllegalArgumentException("Only requested mentorship requests can be accepted.");
        }
        request.setStatus(MentorshipRequest.Status.ACCEPTED);
        return toRequestDto(requestRepository.save(request));
    }

    @Override
    public MentorshipRequestDTO rejectRequest(Long requestId) {
        MentorshipRequest request = getRequest(requestId);
        Employee employee = getLoggedInEmployee();
        requireMentor(request, employee);
        if (request.getStatus() != MentorshipRequest.Status.PENDING) {
            throw new IllegalArgumentException("Only requested mentorship requests can be rejected.");
        }
        request.setStatus(MentorshipRequest.Status.REJECTED);
        return toRequestDto(requestRepository.save(request));
    }

    @Override
    @Transactional(readOnly = true)
    public List<KnowledgeSessionDTO> getMySessions() {
        Employee employee = getLoggedInEmployee();
        return sessionRepository.findByMentorshipRequestMenteeOrMentorshipRequestMentorOrderByScheduledAtAsc(employee, employee)
                .stream().map(this::toSessionDto).collect(Collectors.toList());
    }

    @Override
    public KnowledgeSessionDTO createSession(Long requestId, CreateKnowledgeSessionDTO request) {
        MentorshipRequest mentorship = getRequest(requestId);
        Employee employee = getLoggedInEmployee();
        requireParticipant(mentorship, employee);
        if (mentorship.getStatus() != MentorshipRequest.Status.ACCEPTED) {
            throw new IllegalArgumentException("A knowledge session can only be scheduled for an accepted mentorship request.");
        }
        if (request.getTitle() == null || request.getTitle().isBlank()) {
            throw new IllegalArgumentException("Session title is required.");
        }
        if (request.getScheduledAt() == null || !request.getScheduledAt().isAfter(LocalDateTime.now())) {
            throw new IllegalArgumentException("Session time must be in the future.");
        }
        if (request.getDurationMinutes() == null || request.getDurationMinutes() < 15 || request.getDurationMinutes() > 240) {
            throw new IllegalArgumentException("Session duration must be between 15 and 240 minutes.");
        }

        KnowledgeSession session = new KnowledgeSession();
        session.setMentorshipRequest(mentorship);
        session.setTitle(request.getTitle().trim());
        session.setScheduledAt(request.getScheduledAt());
        session.setDurationMinutes(request.getDurationMinutes());
        session.setNotes(request.getNotes());
        session.setStatus(KnowledgeSession.Status.SCHEDULED);
        return toSessionDto(sessionRepository.save(session));
    }

    @Override
    public KnowledgeSessionDTO completeSession(Long sessionId) {
        KnowledgeSession session = getSession(sessionId);
        Employee employee = getLoggedInEmployee();
        requireParticipant(session.getMentorshipRequest(), employee);
        if (session.getStatus() != KnowledgeSession.Status.SCHEDULED) {
            throw new IllegalArgumentException("Only scheduled sessions can be completed.");
        }
        session.setStatus(KnowledgeSession.Status.COMPLETED);
        return toSessionDto(sessionRepository.save(session));
    }

    @Override
    public void submitFeedback(Long sessionId, CreateFeedbackDTO request) {
        KnowledgeSession session = getSession(sessionId);
        Employee employee = getLoggedInEmployee();
        requireParticipant(session.getMentorshipRequest(), employee);
        if (session.getStatus() != KnowledgeSession.Status.COMPLETED) {
            throw new IllegalArgumentException("Feedback can only be submitted after the session is completed.");
        }
        if (request.getRating() == null || request.getRating() < 1 || request.getRating() > 5) {
            throw new IllegalArgumentException("Rating must be between 1 and 5.");
        }
        if (feedbackRepository.findBySessionAndReviewer(session, employee).isPresent()) {
            throw new ResourceAlreadyExistsException("You have already submitted feedback for this session.");
        }
        KnowledgeSessionFeedback feedback = new KnowledgeSessionFeedback();
        feedback.setSession(session);
        feedback.setReviewer(employee);
        feedback.setRating(request.getRating());
        feedback.setComments(request.getComments());
        feedbackRepository.save(feedback);
    }

    private MentorshipRequest getRequest(Long id) {
        return requestRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Mentorship request not found."));
    }

    private KnowledgeSession getSession(Long id) {
        return sessionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Knowledge session not found."));
    }

    private void requireMentor(MentorshipRequest request, Employee employee) {
        if (request.getMentor() == null || !request.getMentor().getEmployeeId().equals(employee.getEmployeeId())) {
            throw new org.springframework.security.access.AccessDeniedException("Only the mentor can perform this action.");
        }
    }

    private void requireParticipant(MentorshipRequest request, Employee employee) {
        boolean participant = request.getMentor().getEmployeeId().equals(employee.getEmployeeId())
                || request.getMentee().getEmployeeId().equals(employee.getEmployeeId());
        if (!participant) {
            throw new org.springframework.security.access.AccessDeniedException("You are not a participant in this mentorship.");
        }
    }

    private int proficiencyRank(ProficiencyLevel level) {
        if (level == null) return 0;
        return switch (level) {
            case BEGINNER -> 1;
            case INTERMEDIATE -> 2;
            case ADVANCED -> 3;
            case EXPERT -> 4;
        };
    }

    private String fullName(Employee employee) {
        return (Optional.ofNullable(employee.getFirstName()).orElse("") + " "
                + Optional.ofNullable(employee.getLastName()).orElse("")).trim();
    }

    private MentorshipRequestDTO toRequestDto(MentorshipRequest value) {
        MentorshipRequestDTO dto = new MentorshipRequestDTO();
        dto.setRequestId(value.getMentorshipRequestId());
        dto.setMenteeId(value.getMentee().getEmployeeId());
        dto.setMenteeName(fullName(value.getMentee()));
        dto.setMentorId(value.getMentor().getEmployeeId());
        dto.setMentorName(fullName(value.getMentor()));
        dto.setSkillId(value.getSkill().getSkillId());
        dto.setSkillName(value.getSkill().getSkillName());
        dto.setMessage(value.getMessage());
        dto.setStatus(value.getStatus().name());
        dto.setCreatedAt(value.getCreatedAt());
        return dto;
    }

    private KnowledgeSessionDTO toSessionDto(KnowledgeSession value) {
        MentorshipRequest request = value.getMentorshipRequest();
        KnowledgeSessionDTO dto = new KnowledgeSessionDTO();
        dto.setSessionId(value.getKnowledgeSessionId());
        dto.setRequestId(request.getMentorshipRequestId());
        dto.setTitle(value.getTitle());
        dto.setScheduledAt(value.getScheduledAt());
        dto.setDurationMinutes(value.getDurationMinutes());
        dto.setStatus(value.getStatus().name());
        dto.setNotes(value.getNotes());
        dto.setMentorId(request.getMentor().getEmployeeId());
        dto.setMentorName(fullName(request.getMentor()));
        dto.setMenteeId(request.getMentee().getEmployeeId());
        dto.setMenteeName(fullName(request.getMentee()));
        dto.setSkillId(request.getSkill().getSkillId());
        dto.setSkillName(request.getSkill().getSkillName());
        return dto;
    }

    private Employee getLoggedInEmployee() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || authentication.getName() == null || authentication.getName().isBlank()) {
            throw new ResourceNotFoundException("Authenticated employee not found.");
        }
        return employeeRepository.findByOfficialEmail(authentication.getName())
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found."));
    }
}
