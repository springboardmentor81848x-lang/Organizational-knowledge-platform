public class AdminAiServiceImpl {
    
}
