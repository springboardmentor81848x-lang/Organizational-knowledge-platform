package com.okip.dto.manager;
public class ManagerEmployeeOptionDTO {
 private Long employeeId; private String employeeCode; private String employeeName; private String email; private String departmentName; private String currentJobRole; private boolean alreadyInMyTeam;
 public Long getEmployeeId(){return employeeId;} public void setEmployeeId(Long v){employeeId=v;}
 public String getEmployeeCode(){return employeeCode;} public void setEmployeeCode(String v){employeeCode=v;}
 public String getEmployeeName(){return employeeName;} public void setEmployeeName(String v){employeeName=v;}
 public String getEmail(){return email;} public void setEmail(String v){email=v;}
 public String getDepartmentName(){return departmentName;} public void setDepartmentName(String v){departmentName=v;}
 public String getCurrentJobRole(){return currentJobRole;} public void setCurrentJobRole(String v){currentJobRole=v;}
 public boolean isAlreadyInMyTeam(){return alreadyInMyTeam;} public void setAlreadyInMyTeam(boolean v){alreadyInMyTeam=v;}
}
