public class ManagerAiServiceImpl {
    
}
