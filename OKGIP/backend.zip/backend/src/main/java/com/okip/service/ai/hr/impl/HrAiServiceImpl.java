public class HrAiServiceImpl {
    
}
