package com.okip.service.mentorship;

import java.util.List;

import com.okip.dto.mentorship.*;

public interface MentorshipService {
    List<MentorRecommendationDTO> getRecommendations();
    List<MentorshipRequestDTO> getMyRequests();
    MentorshipRequestDTO createRequest(CreateMentorshipRequestDTO request);
    MentorshipRequestDTO acceptRequest(Long requestId);
    MentorshipRequestDTO rejectRequest(Long requestId);
    List<KnowledgeSessionDTO> getMySessions();
    KnowledgeSessionDTO createSession(Long requestId, CreateKnowledgeSessionDTO request);
    KnowledgeSessionDTO completeSession(Long sessionId);
    void submitFeedback(Long sessionId, CreateFeedbackDTO request);
}
