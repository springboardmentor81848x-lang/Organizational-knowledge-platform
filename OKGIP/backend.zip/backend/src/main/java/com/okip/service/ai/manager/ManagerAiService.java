public class ManagerAiService {
    
}
