public class AdminAiService {
    
}
