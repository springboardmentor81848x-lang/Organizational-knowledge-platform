package com.okip.service.notification;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.Message;
import com.okip.dto.notification.NotificationResponseDTO;
import com.okip.entity.master.Employee;
import com.okip.entity.transaction.Notification;
import com.okip.entity.transaction.NotificationDevice;
import com.okip.exception.ResourceNotFoundException;
import com.okip.repository.EmployeeRepository;
import com.okip.repository.NotificationDeviceRepository;
import com.okip.repository.NotificationRepository;

@Service
@Transactional
public class NotificationServiceImpl implements NotificationService {
 private final NotificationRepository notificationRepository;
 private final NotificationDeviceRepository deviceRepository;
 private final EmployeeRepository employeeRepository;
 public NotificationServiceImpl(NotificationRepository n, NotificationDeviceRepository d, EmployeeRepository e){this.notificationRepository=n;this.deviceRepository=d;this.employeeRepository=e;}
 @Override @Transactional(readOnly=true) public List<NotificationResponseDTO> getMine(){return notificationRepository.findTop50ByEmployeeOrderByCreatedAtDesc(current()).stream().map(this::dto).collect(Collectors.toList());}
 @Override public void markRead(Long id){ Notification n=notificationRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Notification not found.")); if(!n.getEmployee().getEmployeeId().equals(current().getEmployeeId())) throw new ResourceNotFoundException("Notification not found."); n.setRead(true); notificationRepository.save(n);}
 @Override public void markAllRead(){ Employee e=current(); notificationRepository.findTop50ByEmployeeOrderByCreatedAtDesc(e).forEach(n->{n.setRead(true);notificationRepository.save(n);}); }
 @Override public void registerFid(String fid){ if(fid==null||fid.isBlank()) throw new IllegalArgumentException("Firebase Installation ID is required."); Employee e=current(); NotificationDevice d=deviceRepository.findByFid(fid).orElseGet(NotificationDevice::new); d.setFid(fid.trim()); d.setEmployee(e); d.setLastSeenAt(LocalDateTime.now()); deviceRepository.save(d); }
 @Override public void notifyEmployee(Long employeeId,String type,String title,String message,String url){ Employee e=employeeRepository.findById(employeeId).orElse(null); if(e==null)return; Notification n=new Notification(); n.setEmployee(e); n.setType(type==null?"GENERAL":type); n.setTitle(title); n.setMessage(message); notificationRepository.save(n);
   for(NotificationDevice d: deviceRepository.findByEmployee(e)){ try{ Message m=Message.builder().setFid(d.getFid()).putData("type",n.getType()).putData("title",n.getTitle()).putData("body",n.getMessage()).putData("url",url==null?"/employee/notifications":url).build(); FirebaseMessaging.getInstance().send(m); }catch(Exception ignored){ /* persistence still succeeds */ } }
 }
 private Employee current(){ Authentication a=SecurityContextHolder.getContext().getAuthentication(); if(a==null||a.getName()==null)throw new ResourceNotFoundException("Authenticated employee not found."); return employeeRepository.findByOfficialEmail(a.getName()).orElseThrow(()->new ResourceNotFoundException("Employee not found.")); }
 private NotificationResponseDTO dto(Notification n){ NotificationResponseDTO d=new NotificationResponseDTO(); d.setNotificationId(n.getNotificationId()); d.setType(n.getType()); d.setTitle(n.getTitle()); d.setMessage(n.getMessage()); d.setRead(n.isRead()); d.setCreatedAt(n.getCreatedAt()); return d; }
}
