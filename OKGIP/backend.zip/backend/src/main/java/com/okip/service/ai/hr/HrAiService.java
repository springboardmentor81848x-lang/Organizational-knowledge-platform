public class HrAiService {
    
}
