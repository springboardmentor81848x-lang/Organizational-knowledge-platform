import React, { useEffect, useMemo, useState } from "react";
import { AlertTriangle, GraduationCap, Loader2 } from "lucide-react";
import ManagerPage from "./ManagerPage";
import managerService from "@/services/managerService";

export default function TrainingManagement() {
  const [data, setData] = useState<any>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");

  const load = () => {
    setLoading(true); setError("");
    managerService.getManagerTrainingAnalytics()
      .then(value => setData(value || {}))
      .catch(err => setError(err?.response?.data?.message || err?.message || "Unable to load training analytics."))
      .finally(() => setLoading(false));
  };
  useEffect(load, []);

  const rows = Array.isArray(data.enrollmentsData) ? data.enrollmentsData : [];
  const filtered = useMemo(() => {
    const q=query.trim().toLowerCase();
    return q ? rows.filter((r:any)=>[r.employeeName,r.trainingName,r.status].some(v=>String(v??"").toLowerCase().includes(q))) : rows;
  },[rows,query]);

  return <ManagerPage title="Training Management" subtitle="Monitor training adoption, progress and completion across your assigned team." icon={GraduationCap} active="Training Management">
    <div className="manager-stat-grid">
      {[
        ["Team Enrollments",data.enrollments??0],["Not Started",data.notStarted??0],
        ["In Progress",data.inProgress??0],["Completed",data.completed??0],
        ["Completion Rate",`${Number(data.completionRate??0).toFixed(1)}%`],["Average Progress",`${Number(data.averageProgress??0).toFixed(1)}%`]
      ].map(([label,value])=><div className="manager-stat-card" key={String(label)}><span>{label}</span><strong>{value}</strong></div>)}
    </div>
    <section className="manager-card manager-data-card">
      <div className="manager-toolbar"><div><span className="manager-section-label">LEARNING ADOPTION</span><h2>Team Training Progress</h2><p>Progress and hours come from employee training activity.</p></div><div className="manager-toolbar-right"><input className="manager-input" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search employee or training..."/><button className="manager-small-btn" onClick={load}>Refresh</button></div></div>
      {loading && <div className="manager-loading"><Loader2 className="spin" size={18}/>Loading training analytics...</div>}
      {!loading && error && <div className="manager-empty-state"><AlertTriangle size={24}/><strong>Unable to load training</strong><p>{error}</p></div>}
      {!loading && !error && filtered.length===0 && <div className="manager-empty-state"><GraduationCap size={24}/><strong>No training activity</strong><p>No training enrollments are available for your team.</p></div>}
      {!loading && !error && filtered.length>0 && <div className="manager-functional-table">
        <div className="manager-functional-head"><span>EMPLOYEE</span><span>TRAINING</span><span>STATUS</span><span>PROGRESS</span><span>HOURS</span></div>
        {filtered.map((r:any)=><div className="manager-functional-row" key={r.employeeTrainingId ?? `${r.employeeId}-${r.trainingId}`}>
          <strong>{r.employeeName||"—"}</strong><span>{r.trainingName||"—"}</span><span>{r.status||"—"}</span><strong>{Number(r.progressPercentage??0).toFixed(1)}%</strong><span>{Number(r.hoursSpent??0).toFixed(1)}</span>
        </div>)}
      </div>}
    </section>
  </ManagerPage>;
}
