import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";

// AUTH
import { Login } from "@/pages/auth/Login";
import { Register } from "@/pages/auth/Register";

// EMPLOYEE
import EmployeeDashboard from "@/pages/employee/Dashboard";
import EmployeeProfile from "@/pages/employee/Profile";
import EmployeeSkills from "@/pages/employee/Skills";
import SelfAssessment from "@/pages/employee/SelfAssessment";
import PeerAssessment from "@/pages/employee/PeerAssessment";
import EmployeeProficiency from "@/pages/employee/Proficiency";
import SkillGapsPage from "@/pages/employee/SkillGapsPage";
import LearningPaths from "@/pages/employee/LearningPaths";
import EmployeeTraining from "@/pages/employee/Training";
import EmployeeProgress from "@/pages/employee/Progress";
import Achievements from "@/pages/employee/Achievements";
import Certifications from "@/pages/employee/Certifications";
import Mentorship from "@/pages/employee/Mentorship";
import EmployeeNotifications from "@/pages/employee/Notifications";
import EmployeeSettings from "@/pages/employee/Settings";
import Experience from "@/pages/employee/Experience";

// HR
import HRDashboard from "@/pages/hr/Dashboard";

// MANAGER
import ManagerDashboard from "@/pages/manager/Dashboard";

// ADMIN
import AdminDashboard from "@/pages/admin/Dashboard";

const App: React.FC = () => {
  return (
    <Routes>

      {/* =====================================================
          AUTH
      ===================================================== */}

      <Route
        path="/"
        element={<Navigate to="/login" replace />}
      />

      <Route
        path="/login"
        element={<Login />}
      />

      <Route
        path="/register"
        element={<Register />}
      />


      {/* =====================================================
          EMPLOYEE
      ===================================================== */}

      <Route
        path="/employee"
        element={<EmployeeDashboard />}
      />

      <Route
        path="/employee/profile"
        element={<EmployeeProfile />}
      />

      <Route
        path="/employee/skills"
        element={<EmployeeSkills />}
      />

      <Route
        path="/employee/self-assessment"
        element={<SelfAssessment />}
      />

      <Route
        path="/employee/peer-assessment"
        element={<PeerAssessment />}
      />

      <Route
        path="/employee/proficiency"
        element={<EmployeeProficiency />}
      />

      <Route
        path="/employee/skill-gaps"
        element={<SkillGapsPage />}
      />

      <Route
        path="/employee/learning-paths"
        element={<LearningPaths />}
      />

      <Route
        path="/employee/training"
        element={<EmployeeTraining />}
      />

      <Route
        path="/employee/experience"
        element={<Experience />}
      />

      <Route
        path="/employee/progress"
        element={<EmployeeProgress />}
      />

      <Route
        path="/employee/achievements"
        element={<Achievements />}
      />

      <Route
        path="/employee/certifications"
        element={<Certifications />}
      />

      <Route
        path="/employee/mentorship"
        element={<Mentorship />}
      />

      <Route
        path="/employee/notifications"
        element={<EmployeeNotifications />}
      />

      <Route
        path="/employee/settings"
        element={<EmployeeSettings />}
      />
       <Route
  path="/hr"
  element={<HRDashboard />}
/>

 <Route
  path="/admin"
  element={<AdminDashboard />}
/>
  <Route
  path="/manager"
  element={<ManagerDashboard />}
/>
      {/* =====================================================
          UNKNOWN ROUTE
      ===================================================== */}

      <Route
        path="*"
        element={<Navigate to="/employee" replace />}
      />

    </Routes>
  );
};

export default App;