import React from "react";
import { BriefcaseBusiness } from "lucide-react";
import ManagerPage from "./ManagerPage";

export default function JobRoles() {
  return (
    <ManagerPage
      title="Job Roles"
      subtitle="Manage role expectations and team role alignment."
      icon={BriefcaseBusiness}
      active="Job Roles"
    />
  );
}
