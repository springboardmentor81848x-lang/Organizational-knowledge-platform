import React from "react";
import { Users } from "lucide-react";
import ManagerPage from "./ManagerPage";

export default function Employees() {
  return (
    <ManagerPage
      title="Employees"
      subtitle="View and manage employees in your team."
      icon={Users}
      active="Employees"
    />
  );
}
