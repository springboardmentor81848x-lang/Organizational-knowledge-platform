import React from "react";
import { BookOpen } from "lucide-react";
import ManagerPage from "./ManagerPage";

export default function CompetencyFramework() {
  return (
    <ManagerPage
      title="Competency Framework"
      subtitle="Manage competency expectations across roles and skills."
      icon={BookOpen}
      active="Competency Framework"
    />
  );
}
