import React from "react";
import WorkspacePage from "@/pages/shared/WorkspacePage.backup";

const Reports: React.FC = () => <WorkspacePage role="MANAGER" page="reports" />;
export default Reports;
