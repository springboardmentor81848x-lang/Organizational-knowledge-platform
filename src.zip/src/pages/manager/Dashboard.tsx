import React, { useEffect, useState } from "react";
import {
  Activity, Award, Bell, CalendarDays, CheckCircle2, ChevronRight, ClipboardCheck,
  FileCheck2, GraduationCap, Moon, Plus, Search, ShieldCheck, Target, TrendingUp, Users, Zap
} from "lucide-react";
import "@/styles/manager-dashboard.css";
import analyticsService, { TeamAnalytics } from "@/services/analyticsService";
import ManagerLayout from "./ManagerLayout";

const heatmap = [
  {
    name: "FRONTEND",
    values: ["92%", "72%", "65%", "88%", "52%", "76%"],
  },
  {
    name: "BACKEND",
    values: ["86%", "82%", "91%", "74%", "55%", "88%"],
  },
  {
    name: "SERVER",
    values: ["89%", "92%", "85%", "65%", "92%", "85%"],
  },
  {
    name: "DATA ENG",
    values: ["62%", "58%", "74%", "90%", "82%", "79%"],
  },
];

const recommendations = [
  {
    label: "PERFORMANCE",
    title: "Projected Upskilling ROI",
    description:
      "Completion of the 'Serverless Security' track by Sarah and David is predicted to reduce.",
  },
  {
    label: "CRITICAL GAP",
    title: "ML Infrastructure Shortage",
    description:
      "Anya Petrova's gap in Kubernetes for ML is becoming a blocking factor for project Orion.",
  },
  {
    label: "READINESS",
    title: "Role Transition Opportunity",
    description:
      "Marcus Thorne shows 92% alignment for a Principal Security role.",
  },
];

const approvals = [
  {
    name: "Elena Rodriguez",
    type: "AWS Certified DevOps Engineer Exam",
    cost: "$300",
    priority: "HIGH",
  },
  {
    name: "Marcus Thorne",
    type: "Advanced Pentesting Workshop",
    cost: "$1,200",
    priority: "MEDIUM",
  },
  {
    name: "Anya Petrova",
    type: "PyTorch for Production Course",
    cost: "$450",
    priority: "STANDARD",
  },
];

const events = [
  {
    title: "React 18 Performance Audit",
    type: "ASSESSMENT",
    date: "Oct 24 • 10:00 AM",
    count: "8 Enrolled",
  },
  {
    title: "Zero Trust Architecture",
    type: "TRAINING",
    date: "Oct 25 • 02:00 PM",
    count: "12 Enrolled",
  },
  {
    title: "GCP Cloud Architect Renewal",
    type: "CERTIFICATION",
    date: "Oct 28 • All Day",
    count: "2 Enrolled",
  },
];

const formatPercent = (value: number) => `${value.toFixed(1)}%`;

const getInitials = (name: string) =>
  name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part.charAt(0).toUpperCase())
    .join("");

export const ManagerDashboard: React.FC = () => {
  const [teamMembers, setTeamMembers] = useState<TeamAnalytics[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        setLoading(true);
        setError("");
        const data = await analyticsService.getTeamAnalytics();
        setTeamMembers(Array.isArray(data) ? data : []);
      } catch (err) {
        console.error("Manager dashboard analytics error:", err);
        setError("Unable to load team analytics.");
        setTeamMembers([]);
      } finally {
        setLoading(false);
      }
    };

    loadDashboardData();
  }, []);

  const filteredTeamMembers = teamMembers.filter((member) => {
    const query = searchTerm.trim().toLowerCase();
    if (!query) return true;
    return (
      member.employeeName?.toLowerCase().includes(query) ||
      member.employeeCode?.toLowerCase().includes(query) ||
      member.jobRoleName?.toLowerCase().includes(query)
    );
  });

  const averageGap = teamMembers.length
    ? teamMembers.reduce((sum, member) => sum + Number(member.gapPercentage || 0), 0) / teamMembers.length
    : 0;

  const averageReadiness = teamMembers.length
    ? teamMembers.reduce((sum, member) => sum + Number(member.readinessPercentage || 0), 0) / teamMembers.length
    : 0;

  const averageCompetency = Math.max(0, 100 - averageGap);

  const stats = [
    { title: "MY TEAM MEMBERS", value: loading ? "..." : String(teamMembers.length), change: "", icon: Users, type: "purple" },
    { title: "TEAM COMPETENCY SCORE", value: loading ? "..." : averageCompetency.toFixed(1), change: "", icon: Target, type: "purple" },
    { title: "TEAM KNOWLEDGE GAP", value: loading ? "..." : formatPercent(averageGap), change: "", icon: Activity, type: "red" },
    { title: "TRAINING COMPLETION", value: "94.2%", change: "", icon: GraduationCap, type: "green" },
    { title: "PENDING ASSESSMENTS", value: "8", change: "", icon: ClipboardCheck, type: "purple" },
    { title: "TEAM READINESS SCORE", value: loading ? "..." : averageReadiness.toFixed(1), change: "", icon: ShieldCheck, type: "green" },
  ];

  return (
    <ManagerLayout active="Dashboard" breadcrumb="Overview">
<section className="manager-content">

  {/* HEADER */}

  <div className="manager-page-header">

    <div>

      <div className="manager-labels">
        <span>ENGINEERING OPS</span>
        <span>● Predictive Insights Active</span>
      </div>

      <h1>Manager Dashboard</h1>

      <p>
        Real-time workforce intelligence for Team Engineering.
        Track proficiency, bridge gaps, and optimize team impact.
      </p>

    </div>

    <div className="manager-header-actions">

      <button>
        <GraduationCap size={13} />
        Assign Training
      </button>

      <button>
        <CheckCircle2 size={13} />
        Approve Requests
      </button>

      <button>
        <FileCheck2 size={13} />
        Generate Team Report
      </button>

      <button className="primary-action">
        ↓
        Export Dashboard
      </button>

    </div>

  </div>

  {/* ================= STATS ================= */}

  <div className="manager-stats">

    {stats.map((stat) => {

      const Icon = stat.icon;

      return (
        <div
          className="manager-stat-card"
          key={stat.title}
        >

          <div className="manager-stat-top">

            <div
              className={`manager-stat-icon ${stat.type}`}
            >
              <Icon size={14} />
            </div>

            {stat.change && (
              <span
                className={`manager-stat-change ${stat.type}`}
              >
                {stat.change}
              </span>
            )}

          </div>

          <span className="manager-stat-title">
            {stat.title}
          </span>

          <strong className="manager-stat-value">
            {stat.value}
          </strong>

          <div className="manager-stat-line">
            <span />
          </div>

        </div>
      );
    })}

  </div>

  {/* ================= HEATMAP + AI ================= */}

  <div className="manager-main-grid">

    {/* HEATMAP */}

    <section className="manager-card heatmap-card">

      <CardTitle
        title="Team Knowledge Gap Heatmap"
        subtitle="Proficiency levels across strategic technology domains."
      />

      <div className="heatmap-legend">
        <span>
          <i className="expert" />
          EXPERT
        </span>

        <span>
          <i className="learning" />
          LEARNING
        </span>

        <span>
          <i className="critical" />
          CRITICAL
        </span>
      </div>

      <div className="heatmap">

        <div className="heatmap-header">
          <span />
          <span>CLOUD</span>
          <span>SECURITY</span>
          <span>DEVOPS</span>
          <span>DATA</span>
          <span>AI/ML</span>
          <span>ARCHITECTURE</span>
        </div>

        {heatmap.map((row) => (

          <div
            className="heatmap-row"
            key={row.name}
          >

            <strong>{row.name}</strong>

            {row.values.map((value, index) => {

              const numeric =
                parseInt(value);

              let level = "expert";

              if (numeric < 60) {
                level = "critical";
              } else if (numeric < 75) {
                level = "learning";
              }

              return (
                <div
                  className={`heatmap-cell ${level}`}
                  key={index}
                >
                  {value}
                </div>
              );
            })}

          </div>

        ))}

      </div>

    </section>

    {/* AI MANAGER INSIGHTS */}

    <section className="manager-card ai-manager-card">

      <div className="ai-manager-heading">

        <div className="ai-icon">
          <Zap size={17} />
        </div>

        <div>
          <h2>AI Manager Insights</h2>
          <p>Predictive team intelligence feed.</p>
        </div>

      </div>

      <div className="ai-image-placeholder">
        <div>
          <strong>Intelligence Active</strong>
          <span>UPDATED: 2M AGO</span>
        </div>

        <i />
      </div>

      <div className="recommendation-list">

        {recommendations.map((item) => (

          <div
            className="manager-recommendation"
            key={item.title}
          >

            <span>{item.label}</span>

            <strong>{item.title}</strong>

            <p>{item.description}</p>

            <button>
              Review
              <ChevronRight size={11} />
            </button>

          </div>

        ))}

      </div>

      <button className="view-recommendations">
        Review All Recommendations
        <ChevronRight size={12} />
      </button>

    </section>

  </div>

  {/* ================= TEAM DIRECTORY ================= */}

  <section className="manager-card team-directory">

    <div className="directory-header">

      <CardTitle
        title="Team Directory & Performance"
        subtitle="Granular metrics for each direct report."
      />

      <div className="directory-search">
        <Search size={12} />
        <input
          placeholder="Search team..."
          value={searchTerm}
          onChange={(event) => setSearchTerm(event.target.value)}
        />
      </div>

    </div>

    <div className="employee-table">

      <div className="employee-table-head">
        <span>Employee</span>
        <span>Role</span>
        <span>Competency</span>
        <span>Gap</span>
        <span>Training</span>
        <span>Cert</span>
        <span>Rating</span>
      </div>

      {loading ? (
        <div className="employee-table-row">
          <span>Loading team members...</span>
        </div>
      ) : error ? (
        <div className="employee-table-row">
          <span>{error}</span>
        </div>
      ) : filteredTeamMembers.length === 0 ? (
        <div className="employee-table-row">
          <span>No team members found.</span>
        </div>
      ) : (
        filteredTeamMembers.map((employee) => {
          const gap = Number(employee.gapPercentage || 0);
          const competency = Math.max(0, 100 - gap);
          const readiness = Number(employee.readinessPercentage || 0);
          const initials = getInitials(employee.employeeName || employee.employeeCode || "");

          return (
            <div
              className="employee-table-row"
              key={employee.employeeId}
            >
              <div className="employee-name">
                <div className="employee-avatar">
                  {initials || "--"}
                </div>
                <div>
                  <strong>{employee.employeeName}</strong>
                  <small>{employee.employeeCode}</small>
                </div>
              </div>

              <span className="employee-role">
                {employee.jobRoleName || "—"}
              </span>

              <strong className="competency">
                {formatPercent(competency)}
              </strong>

              <strong className="gap">
                {formatPercent(gap)}
              </strong>

              <div className="training-progress">
                <div>
                  <span style={{ width: `${Math.min(100, Math.max(0, readiness))}%` }} />
                </div>
                <small>{formatPercent(readiness)}</small>
              </div>

              <span className="cert-status">
                —
              </span>

              <span className="rating">
                —
              </span>
            </div>
          );
        })
      )}

    </div>

    <CardFooter text="View Full Team Analytics" />

  </section>

  {/* ================= CHARTS + EMPLOYEE SPOTLIGHT ================= */}

  <div className="manager-lower-grid">

    {/* TEAM GROWTH */}

    <section className="manager-card chart-card">

      <CardTitle
        title="Team Growth Velocity"
        subtitle="Tracking competency vs knowledge gap reduction."
      />

      <div className="line-chart">

        <div className="chart-y">
          <span>100</span>
          <span>75</span>
          <span>50</span>
          <span>25</span>
          <span>0</span>
        </div>

        <div className="chart-area">

          <div className="growth-line" />

          <div className="gap-line" />

          <div className="chart-months">
            <span>Jan</span>
            <span>Feb</span>
            <span>Mar</span>
            <span>Apr</span>
            <span>May</span>
            <span>Jun</span>
          </div>

        </div>

      </div>

      <div className="chart-legend">
        <span>
          <i className="purple-dot" />
          Competency Index
        </span>

        <span>
          <i className="red-dot" />
          Knowledge Gap
        </span>
      </div>

    </section>

    {/* TRAINING COMPLETION */}

    <section className="manager-card chart-card">

      <CardTitle
        title="Training Completion Rate"
        subtitle="Monthly percentage of successfully completed learning paths."
      />

      <div className="bar-chart">

        {[
          "65%",
          "70%",
          "72%",
          "78%",
          "88%",
          "94%",
        ].map((height, index) => (

          <div
            className="bar-item"
            key={index}
          >
            <div className="bar-wrapper">
              <div
                className="bar"
                style={{
                  height,
                }}
              />
            </div>

            <span>
              {[
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "Jun",
              ][index]}
            </span>

          </div>

        ))}

      </div>

      <div className="chart-legend">
        <span>
          <i className="green-dot" />
          Completion %
        </span>
      </div>

    </section>

    {/* EMPLOYEE SPOTLIGHT */}

    <section className="manager-card employee-spotlight">

      <div className="spotlight-code">
        {teamMembers[0]?.employeeCode || "—"}
      </div>

      <div className="spotlight-avatar">
        {getInitials(teamMembers[0]?.employeeName || "")}
        <i />
      </div>

      <h2>{teamMembers[0]?.employeeName || "No employee selected"}</h2>

      <span className="spotlight-role">
        {teamMembers[0]?.jobRoleName || "—"}
      </span>

      <div className="spotlight-badges">
        <span>LVL 5</span>
        <span>★ Expert</span>
      </div>

      <div className="spotlight-stats">

        <div>
          <span>COMPETENCY</span>
          <strong>{teamMembers[0] ? formatPercent(Math.max(0, 100 - Number(teamMembers[0].gapPercentage || 0))) : "—"}</strong>
        </div>

        <div>
          <span>GAP INDEX</span>
          <strong>{teamMembers[0] ? formatPercent(Number(teamMembers[0].gapPercentage || 0)) : "—"}</strong>
        </div>

      </div>

      <h3>Skill Breakdown</h3>

      <SkillBar
        name="Team readiness"
        value={teamMembers[0] ? formatPercent(Number(teamMembers[0].readinessPercentage || 0)) : "0%"}
      />

      <SkillBar
        name="Knowledge gap"
        value={teamMembers[0] ? formatPercent(Number(teamMembers[0].gapPercentage || 0)) : "0%"}
      />

      <SkillBar
        name="Competency index"
        value={teamMembers[0] ? formatPercent(Math.max(0, 100 - Number(teamMembers[0].gapPercentage || 0))) : "0%"}
      />

      <div className="growth-path">

        <small>AI GROWTH PATHWAY</small>

        <strong>
          "Recommended: Advanced Distributed Systems
          certification to unlock Principal Role transition."
        </strong>

        <button>
          Open Talent Map
          <ChevronRight size={11} />
        </button>

      </div>

      <h3>Pending Actions</h3>

      <button className="pending-action">
        <GraduationCap size={12} />
        Assign Security Track
      </button>

      <button className="pending-action">
        <CalendarDays size={12} />
        Schedule Annual Review
      </button>

      <CardFooter text="Comprehensive Performance Log" />

    </section>

  </div>

  {/* ================= APPROVALS + EVENTS ================= */}

  <div className="manager-bottom-grid">

    <section className="manager-card approval-card">

      <div className="approval-heading">
        <CardTitle
          title="Team Approval Queue"
          subtitle="Training and assessment requests requiring your sign-off."
        />

        <span>3 PENDING ACTIONS</span>
      </div>

      <div className="approval-table">

        <div className="approval-head">
          <span>REQUESTED BY</span>
          <span>REQUEST TYPE</span>
          <span>COST/IMPACT</span>
          <span>PRIORITY</span>
          <span>ACTIONS</span>
        </div>

        {approvals.map((item) => (

          <div
            className="approval-row"
            key={item.name}
          >

            <strong>{item.name}</strong>

            <span>{item.type}</span>

            <strong className="cost">
              {item.cost}
            </strong>

            <span
              className={`priority ${item.priority.toLowerCase()}`}
            >
              {item.priority}
            </span>

            <div className="approval-actions">
              <button>
                ✓
              </button>

              <button>
                +
              </button>
            </div>

          </div>

        ))}

      </div>

      <CardFooter text="Open All Pending Requests" />

    </section>

    {/* EVENTS */}

    <section className="manager-card events-card">

      <div className="events-title">
        <div>
          <h2>Upcoming Team Events</h2>
        </div>

        <span>CALENDAR</span>
      </div>

      {events.map((event) => (

        <div
          className="event-item"
          key={event.title}
        >

          <div className="event-icon">
            <CalendarDays size={14} />
          </div>

          <div className="event-info">
            <strong>{event.title}</strong>
            <span>{event.date}</span>
          </div>

          <div className="event-meta">
            <b>{event.type}</b>
            <small>{event.count}</small>
          </div>

        </div>

      ))}

      <CardFooter text="View Full Schedule" />

    </section>

  </div>

  {/* ================= QUICK ACTIONS ================= */}

  <div className="manager-quick-actions">

    <QuickAction
      icon={Plus}
      title="Assign Training"
      subtitle="Select paths for individuals"
    />

    <QuickAction
      icon={Target}
      title="New Assessment"
      subtitle="Create a skill checkpoint"
    />

    <QuickAction
      icon={Award}
      title="Verify Certificates"
      subtitle="Audit team credentials"
    />

    <QuickAction
      icon={Zap}
      title="AI Strategy Sync"
      subtitle="Re-analyze workforce gaps"
    />

  </div>

</section>
    </ManagerLayout>
  );
};

export default ManagerDashboard;

/* Shared dashboard content helpers */
function CardTitle({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="manager-card-title">
      <h2>{title}</h2>
      {subtitle && <p>{subtitle}</p>}
    </div>
  );
}

function CardFooter({ text }: { text: string }) {
  return (
    <div className="manager-card-footer">
      <button type="button">{text}<ChevronRight size={12} /></button>
    </div>
  );
}

function SkillBar({ name, value }: { name: string; value: string }) {
  return (
    <div className="skill-bar-item">
      <div><span>{name}</span><strong>{value}</strong></div>
      <div className="skill-bar-track"><span style={{ width: value }} /></div>
    </div>
  );
}

function QuickAction({ icon: Icon, title, subtitle }: {
  icon: React.ElementType;
  title: string;
  subtitle: string;
}) {
  return (
    <button className="manager-quick-action" type="button">
      <div className="quick-action-icon"><Icon size={15} /></div>
      <div><strong>{title}</strong><span>{subtitle}</span></div>
    </button>
  );
}
