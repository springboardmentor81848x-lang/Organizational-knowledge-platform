import React from "react";
import { BarChart3 } from "lucide-react";
import ManagerPage from "./ManagerPage";

export default function KnowledgeGapAnalysis() {
  return (
    <ManagerPage
      title="Knowledge Gap Analysis"
      subtitle="Identify team skill gaps and high-risk capability shortages."
      icon={BarChart3}
      active="Knowledge Gap Analysis"
    />
  );
}
