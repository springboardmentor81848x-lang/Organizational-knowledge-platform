import React from "react";
import WorkspacePage from "@/pages/shared/WorkspacePage.backup";

const TrainingManagement: React.FC = () => <WorkspacePage role="MANAGER" page="training-management" />;
export default TrainingManagement;
