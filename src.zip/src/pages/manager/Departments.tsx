import React from "react";
import { Building2 } from "lucide-react";
import ManagerPage from "./ManagerPage";

export default function Departments() {
  return (
    <ManagerPage
      title="Departments"
      subtitle="Review department structure and skill coverage."
      icon={Building2}
      active="Departments"
    />
  );
}
