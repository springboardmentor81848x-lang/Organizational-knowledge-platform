import React from "react";
import WorkspacePage from "@/pages/shared/WorkspacePage.backup";

const Settings: React.FC = () => <WorkspacePage role="MANAGER" page="settings" />;
export default Settings;
