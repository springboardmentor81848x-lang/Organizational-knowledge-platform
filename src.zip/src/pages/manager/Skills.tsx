import React from "react";
import WorkspacePage from "@/pages/shared/WorkspacePage.backup";

const Skills: React.FC = () => <WorkspacePage role="MANAGER" page="skills" />;
export default Skills;
